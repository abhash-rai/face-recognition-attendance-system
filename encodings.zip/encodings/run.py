import numpy as np
import cv2
import pickle
import datetime

def start_session(encodings_list, enodings_ids, face_location_model, face_encoding_model, camera_index=0, show_preview=True, scale_frame=0.77, desired_fps=2, tolerance=0.44):

    def get_current_date() -> str:
        """
        Get the current date and returns a string representing the current date in the format 'YYYY-MM-DD'.
        """
        current_date = datetime.date.today()
        return str(current_date)
    
    def get_current_time() -> str:
        '''Gets the current timestamp with seconds precision, converts it to string, and returns it'''
        return datetime.datetime.now().strftime('%H:%M:%S')

    enodings_ids = np.array(enodings_ids)

    try:

        cap = cv2.VideoCapture(camera_index)
        frame_delay = int(1000 / desired_fps)  # Delay in milliseconds between frames based on the desired FPS
        
        while True:
            ret, frame = cap.read()

            small_frame = cv2.resize(frame, (0, 0), fx=scale_frame, fy=scale_frame) # Resize the frame for faster processing
            rgb_frame = small_frame[:, :, ::-1] # Convert the frame from BGR to RGB

            face_locations = face_recognition.face_locations(rgb_frame, model=face_location_model) # Find face locations and face encodings in the frame
            unknown_face_encodings = face_recognition.face_encodings(rgb_frame, face_locations, model=face_encoding_model) # Generate encodings of every faces in the frame in a list
            number_of_faces_detected = len(unknown_face_encodings)

            identified_student_ids = []

            if number_of_faces_detected != 0: # Send data only if one or more person is detected
                date = get_current_date()
                time = get_current_time()

                for unknown_face in unknown_face_encodings:

                    identified_id = None

                    status = face_recognition.api.compare_faces(encodings_list, unknown_face, tolerance=tolerance)

                    if True in status:
                        status = np.array(status)

                        recognized_ids_indexes = np.where(status)[0]
                        recognized_ids = enodings_ids[recognized_ids_indexes]
                        
                        unique_ids, counts = np.unique(recognized_ids, return_counts=True)
                        max_number_of_counts = np.max(counts)

                        if np.count_nonzero(counts == max_number_of_counts) == 1:
                            max_count_index = np.where(counts == max_number_of_counts)[0][0]
                            identified_id = unique_ids[max_count_index]
                            ####### Make known entry to database here

                    else:
                        identified_id = 'Unknown'

                        ####### Make unknown entry to database here
                    
                    identified_student_ids.append(identified_id)

            if show_preview == True: 

                # Draw rectangles around detected faces and display names on 'the scaled frame'
                for (top, right, bottom, left), identity in zip(face_locations, identified_student_ids):
                    cv2.rectangle(small_frame, (left, top), (right, bottom), (0, 255, 0), 2)
                    cv2.putText(small_frame, identity, (left, bottom + 20), cv2.FONT_HERSHEY_DUPLEX, 0.5, (0, 255, 0), 1)
                
                cv2.imshow('Attendance Session Started', small_frame) # Display the frame with face rectangles
                
                if cv2.waitKey(frame_delay) & 0xFF == ord('q'): # Break the loop if 'q' key is pressed
                    break

    except KeyboardInterrupt:
        pass  # Handle keyboard interrupt (e.g., for clean exit)

    finally:
        cap.release()  # Release the camera
        cv2.destroyAllWindows()  # Close OpenCV windows
        # self.__connection.close()
        # self.__cursor.close()


with open('./multiple_angles_faces_encodings', 'rb') as file:
    data = pickle.load(file)

ids, encodings_list = [], []
for id, encodings in data.items():
    for _ in range(5):
        ids.append(id)
    encodings_list.extend(encodings)

start_session(encodings_list, ids, 'hog', 'small')
